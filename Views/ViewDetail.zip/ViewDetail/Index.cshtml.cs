using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace VVA.ITS.WebApp.Views.ViewDetail
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
