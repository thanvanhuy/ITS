<?php
require_once ("db.php");
require_once ("pagination.class.php");
$perPage = new PerPage();
$sql = "SELECT * from php_interview_questions";
$paginationlink = "getresult.php?page=";
$page = 1;
if (! empty($_GET["page"])) {
    $page = $_GET["page"];
}
$start = ($page - 1) * $perPage->perpage;
if ($start < 0) {
    $start = 0;
}
$statement = $connection->prepare($sql);
$statement->execute();
$result = $statement->get_result();
$perpageresult = $perPage->perpage($result->num_rows, $paginationlink);
$query = $sql . " limit " . $start . "," . $perPage->perpage;
$statement = $connection->prepare($query);
$statement->execute();
$result = $statement->get_result();
$output = '';
while ($row = mysqli_fetch_array($result)) {
    $output .= '<div class="question"><input type="hidden" id="rowcount" name="rowcount" value="' . $result->num_rows . '" />' . $row["question"] . '</div>';
    $output .= '<div class="answer">' . $row["answer"] . '</div>';
}
if (! empty($perpageresult)) {
    $output .= '<div id="pagelink">' . $perpageresult . '</div>';
}
print $output;
?>